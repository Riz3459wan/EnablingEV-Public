import { memo } from "react";
import { Leaf, ShieldCheck, Zap, ArrowRight } from "lucide-react";
import { Link } from "react-router";
import ImageWithFallback from "../components/ImageWithFallback";
import aboutImg from "../assets/about/about.webp";

const PILLARS = [
  { icon: Leaf, title: "Cleaner", desc: "Zero tailpipe emissions" },
  { icon: ShieldCheck, title: "Dependable", desc: "Built for daily use" },
  { icon: Zap, title: "Efficient", desc: "Lower running costs" },
];

const MissionSection = memo(() => (
  <section
    id="mission"
    className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-surface text-white"
  >
    <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
      <div className="relative">
        <div className="rounded-2xl overflow-hidden h-[420px] sm:h-[500px] border border-border">
          <ImageWithFallback
            src={aboutImg}
            alt="Enabling EV electric rickshaw"
            label="Engineered in India"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute -bottom-5 left-6 bg-background border border-border rounded-xl px-4 py-2.5">
          <p className="font-display tabular text-lg font-semibold text-white leading-none">
            2013
          </p>
          <p className="text-muted-foreground text-xs mt-1">
            Where it started
          </p>
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2.5 mb-5">
          <span className="h-px w-8 bg-accent" />
          <span className="text-sm text-muted-foreground">Our mission</span>
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-6 leading-tight text-balance">
          Mobility that enables progress.
        </h2>
        <p className="text-muted-foreground mb-8 text-base sm:text-lg leading-relaxed">
          EnablingEV builds practical electric vehicles for the people who
          keep India moving. Our focus is simple: dependable engineering,
          economical ownership, and support that lasts beyond the sale.
        </p>

        <Link
          to="/about"
          className="inline-flex text-primary text-sm font-medium items-center gap-1.5 hover:gap-2.5 hover:text-primary-hover transition-all mb-10"
        >
          Learn more about us <ArrowRight size={16} />
        </Link>

        <div className="grid grid-cols-3 border-t border-border pt-7">
          {PILLARS.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="pr-4">
              <Icon size={20} className="text-accent mb-3" />
              <h4 className="font-semibold mb-1 text-white text-sm sm:text-base">
                {title}
              </h4>
              <p className="text-muted-foreground text-xs sm:text-sm">
                {desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
));

export default MissionSection;
