import { memo } from "react";
import Carousel from "../components/Carousel";
import r1 from "../assets/gallery/Rikshaw1.webp";
import r3 from "../assets/gallery/Rikshaw3.webp";
import r4 from "../assets/gallery/Rikshaw4.webp";
import r5 from "../assets/gallery/Rikshaw5.webp";
import r6 from "../assets/gallery/Rikshaw6.webp";

const slides = [
  { src: r4, alt: "JhatPat Jio electric rickshaw on the road" },
  { src: r1, alt: "EnablingEV electric rickshaw" },
  { src: r5, alt: "Electric rickshaw fleet" },
  { src: r3, alt: "JhatPat Jio in service" },
  { src: r6, alt: "EnablingEV vehicle showcase" },
];

const CarouselSection = memo(() => (
  <section className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-8">
    <Carousel slides={slides} />
  </section>
));

export default CarouselSection;
