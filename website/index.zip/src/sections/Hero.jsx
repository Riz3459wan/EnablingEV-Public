import { memo } from "react";
import { useNavigate } from "react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { PrimaryButton, EmberButton } from "../components/ui/Button";
import ImageWithFallback from "../components/ImageWithFallback";
import heroImg from "../assets/products/F2SS1.webp";

const LEDGER = [
  { value: "2013", label: "Founded, Ghaziabad" },
  { value: "2", label: "Vehicle families" },
  { value: "135–160", label: "AH battery range" },
  { value: "18 mo.", label: "Max motor warranty" },
];

const Hero = memo(({ onExplore }) => {
  const navigate = useNavigate();

  return (
    <section
      id="home"
      className="relative bg-ev-grid text-white overflow-hidden pt-16 sm:pt-20"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-[1.05fr_1fr] gap-10 lg:gap-4 items-end">
        {/* Left: copy */}
        <div className="relative z-10 pb-14 lg:pb-24">
          <div className="flex items-center gap-2.5 mb-7">
            <span className="h-px w-8 bg-accent" />
            <span className="text-sm text-muted-foreground">
              Electric mobility, engineered in Uttar Pradesh
            </span>
          </div>

          <h1 className="font-display text-[2.75rem] sm:text-6xl lg:text-[4.5rem] font-semibold leading-[1.03] mb-6 text-white text-balance">
            Vehicles built to
            <br />
            earn their keep.
          </h1>

          <p className="text-muted-foreground text-lg leading-relaxed mb-9 max-w-md">
            Passenger and cargo electric rickshaws designed for daily routes,
            everyday livelihoods, and running costs that actually add up.
          </p>

          <div className="flex flex-wrap items-center gap-3.5">
            <PrimaryButton onClick={onExplore}>
              Explore vehicles <ArrowRight size={18} />
            </PrimaryButton>
            <EmberButton onClick={() => navigate("/DealerForm")}>
              Become a dealer <ArrowUpRight size={18} />
            </EmberButton>
          </div>
        </div>

        {/* Right: vehicle image, bleeding past the grid, no card frame */}
        <div className="relative lg:-mr-4">
          <div className="relative aspect-[4/3.1] lg:aspect-[1/1.05]">
            <div className="absolute -inset-x-6 -inset-y-4 bg-gradient-to-t from-background via-transparent to-transparent lg:hidden" />
            <ImageWithFallback
              src={heroImg}
              alt="JhatPat F2 SS electric rickshaw"
              label="JhatPat F2 SS"
              loading="eager"
              className="w-full h-full object-contain object-bottom"
            />
          </div>
        </div>
      </div>

      {/* Ledger strip — real figures, tabular alignment, hairline dividers */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 sm:grid-cols-4 border-t border-border">
          {LEDGER.map((item) => (
            <div
              key={item.label}
              className="border-r border-border last:border-r-0 py-6 pr-4"
            >
              <p className="font-display tabular text-2xl sm:text-3xl font-semibold text-white">
                {item.value}
              </p>
              <p className="text-muted-foreground text-xs sm:text-sm mt-1">
                {item.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

export default Hero;
