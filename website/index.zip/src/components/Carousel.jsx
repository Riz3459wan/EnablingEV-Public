import { useState, useEffect, useCallback, memo } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

const Carousel = memo(({ slides = [], interval = 5000 }) => {
  const [index, setIndex] = useState(0);

  const next = useCallback(() => {
    if (!slides.length) return;
    setIndex((i) => (i + 1) % slides.length);
  }, [slides.length]);

  const prev = useCallback(() => {
    if (!slides.length) return;
    setIndex((i) => (i - 1 + slides.length) % slides.length);
  }, [slides.length]);

  useEffect(() => {
    if (!slides.length) return;
    const timer = setInterval(next, interval);
    return () => clearInterval(timer);
  }, [next, interval, slides.length]);

  if (!slides || slides.length === 0) {
    return null;
  }

  return (
    <div
      className="relative w-full rounded-2xl overflow-hidden border border-border bg-surface shadow-xl select-none"
      style={{ minHeight: "260px", height: "clamp(260px, 35vw, 450px)" }}
    >
      {slides.map((slide, i) => (
        <img
          key={i}
          src={slide.src}
          alt={slide.alt}
          loading={i === 0 ? "eager" : "lazy"}
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ease-in-out ${
            i === index
              ? "opacity-100 z-10"
              : "opacity-0 pointer-events-none z-0"
          }`}
        />
      ))}

      {/* Dark overlay taaki arrows aur dots cleanly dikhein */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/20 pointer-events-none z-20" />

      {/* Prev Button */}
      <button
        type="button"
        onClick={prev}
        aria-label="Previous slide"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-black/60 border border-white/20 hover:border-accent hover:bg-black/80 rounded-full p-2.5 text-white transition-all cursor-pointer active:scale-95"
      >
        <ChevronLeft size={22} />
      </button>

      {/* Next Button */}
      <button
        type="button"
        onClick={next}
        aria-label="Next slide"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-black/60 border border-white/20 hover:border-accent hover:bg-black/80 rounded-full p-2.5 text-white transition-all cursor-pointer active:scale-95"
      >
        <ChevronRight size={22} />
      </button>

      {/* Indicator Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-30 bg-black/40 px-3 py-1.5 rounded-full backdrop-blur-sm border border-white/10">
        {slides.map((_, i) => (
          <button
            type="button"
            key={i}
            onClick={() => setIndex(i)}
            aria-label={`Go to slide ${i + 1}`}
            className={`h-2 rounded-full transition-all cursor-pointer ${
              i === index
                ? "w-6 bg-accent"
                : "w-2 bg-white/40 hover:bg-white/60"
            }`}
          />
        ))}
      </div>
    </div>
  );
});

export default Carousel;
