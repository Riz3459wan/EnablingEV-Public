import { memo, Fragment } from "react";
import { Link } from "react-router";
import { Users, MapPin, Phone, Mail } from "lucide-react";
import BrandMark from "./ui/BrandMark";
import { SocialIcon } from "./ui/SocialIcons";
import { PHONES, EMAIL, OFFICES, SOCIALS } from "../data/company";

// The old site's footer showed the Bihar office (full list is on /contact).
const FOOTER_OFFICE = OFFICES.find((o) => o.label === "Bihar Office");

const Footer = memo(({ onOpenDealer }) => (
  <footer className="border-t border-border bg-background pt-20 pb-10 px-4 sm:px-6 lg:px-8 text-white">
    <div className="max-w-7xl mx-auto">
      {/* Footer Links */}
      <div className="grid grid-cols-2 md:grid-cols-[1.1fr_0.8fr_0.8fr_1.6fr] gap-10 mb-16">
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2 mb-4">
            <BrandMark className="h-8 w-auto" />
            <span className="font-display font-semibold text-xl text-white tracking-tight">
              Enabling<span className="text-accent">EV</span>
            </span>
          </div>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Sustainable electric vehicles for India's passenger and cargo
            needs.
          </p>
        </div>

        <div>
          <h4 className="font-semibold mb-4 text-white">Company</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li>
              <Link to="/about" className="hover:text-white transition-colors">
                About
              </Link>
            </li>
            <li>
              <Link
                to="/mission"
                className="hover:text-white transition-colors"
              >
                Mission
              </Link>
            </li>
            <li>
              <Link
                to="/gallery"
                className="hover:text-white transition-colors"
              >
                Gallery
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold mb-4 text-white">Mobility</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li>
              <Link
                to="/product"
                className="hover:text-white transition-colors"
              >
                Passenger EV
              </Link>
            </li>
            <li>
              <Link
                to="/product"
                className="hover:text-white transition-colors"
              >
                Cargo EV
              </Link>
            </li>
          </ul>
        </div>

        <div className="col-span-2 md:col-span-1">
          <h4 className="font-semibold mb-4 text-white">Contact Us</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li>
              <button
                onClick={onOpenDealer}
                className="flex items-center gap-2 hover:text-accent transition-colors"
              >
                <Users size={16} className="text-accent" /> Dealer
                enquiries
              </button>
            </li>
            <li className="flex items-start gap-2">
              <MapPin size={16} className="text-accent shrink-0 mt-0.5" />
              <span>
                <strong className="text-white font-medium">
                  {FOOTER_OFFICE.label}:
                </strong>{" "}
                {FOOTER_OFFICE.address}
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Phone size={16} className="text-accent shrink-0 mt-0.5" />
              <span>
                <strong className="text-white font-medium">Mobile No:</strong>{" "}
                {PHONES.map((p, i) => (
                  <Fragment key={p.href}>
                    {i > 0 && ", "}
                    <a
                      href={p.href}
                      className="hover:text-white transition-colors"
                    >
                      {p.display}
                    </a>
                  </Fragment>
                ))}
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Mail size={16} className="text-accent shrink-0 mt-0.5" />
              <span>
                <strong className="text-white font-medium">Email:</strong>{" "}
                <a
                  href={`mailto:${EMAIL}`}
                  className="hover:text-white transition-colors"
                >
                  {EMAIL}
                </a>
              </span>
            </li>
          </ul>

          <div className="flex gap-3 mt-5">
            {SOCIALS.map(({ name, href, label }) => (
              <a
                key={name}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="w-9 h-9 rounded-full bg-surface border border-border flex items-center justify-center text-accent hover:text-white hover:border-accent/50 transition-colors"
              >
                <SocialIcon name={name} size={16} />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground">
        <p>© 2026 Enabling E-Vehicle Private Limited. All rights reserved.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-white transition-colors">
            Privacy Policy
          </a>
          <a href="#" className="hover:text-white transition-colors">
            Terms of Service
          </a>
        </div>
      </div>
    </div>
  </footer>
));

export default Footer;
