import { Link } from "react-router";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import Card from "../ui/Card";
import BrandMark from "../ui/BrandMark";

// Split-screen auth layout: left = role branding panel (hidden on mobile),
// right = the actual form. Shared by Admin/SubAdmin/Dealer login so each
// page only supplies its own copy, icon and bullet points.
const AuthShell = ({
  icon: Icon,
  roleLabel,
  title,
  subtitle,
  bullets = [],
  children,
}) => (
  <div className="min-h-screen flex bg-background text-white">
    {/* Left branding panel */}
    <div className="hidden lg:flex lg:w-[45%] relative flex-col justify-between p-12 overflow-hidden border-r border-border">
      <div className="pointer-events-none absolute top-0 left-0 w-[500px] h-[500px] bg-accent/15 blur-[140px] rounded-full -z-10" />
      <div className="pointer-events-none absolute bottom-0 right-0 w-[400px] h-[400px] bg-primary/10 blur-[120px] rounded-full -z-10" />

      <Link to="/" className="flex items-center gap-2.5 text-white w-fit">
        <BrandMark className="h-9 w-auto" />
        <span className="font-bold text-xl tracking-tight text-white">
          Enabling<span className="text-accent">EV</span>
        </span>
      </Link>

      <div>
        <div className="bg-surface border border-line w-14 h-14 rounded-2xl flex items-center justify-center mb-6">
          <Icon size={26} className="text-accent" />
        </div>
        <p className="text-accent text-xs sm:text-sm font-semibold tracking-wider mb-3 uppercase">
          {roleLabel} portal
        </p>
        <h2 className="text-3xl lg:text-4xl font-bold tracking-tight text-white mb-4 leading-tight">
          {title}
        </h2>
        <p className="text-muted-foreground text-base leading-relaxed mb-8 max-w-sm">
          {subtitle}
        </p>

        {bullets.length > 0 && (
          <ul className="space-y-3">
            {bullets.map((b) => (
              <li
                key={b}
                className="flex items-start gap-2.5 text-sm text-muted-foreground"
              >
                <CheckCircle2
                  size={17}
                  className="text-primary shrink-0 mt-0.5"
                />
                {b}
              </li>
            ))}
          </ul>
        )}
      </div>

      <p className="text-xs text-placeholder">
        © 2026 Enabling E-Vehicle Private Limited.
      </p>
    </div>

    {/* Right form panel */}
    <div className="flex-1 flex items-center justify-center px-4 py-16 sm:py-24 relative">
      <div className="pointer-events-none absolute top-10 left-1/2 -translate-x-1/2 w-[500px] h-[400px] bg-accent/10 blur-[140px] rounded-full -z-10 lg:hidden" />

      <div className="w-full max-w-sm">
        <Link
          to="/"
          className="lg:hidden flex items-center gap-2 text-muted-foreground hover:text-white text-sm mb-8 transition-colors w-fit"
        >
          <ArrowLeft size={16} /> Back to home
        </Link>

        <Card className="p-6 sm:p-8">
          <div className="lg:hidden bg-surface border border-line w-12 h-12 rounded-xl flex items-center justify-center mb-5">
            <Icon size={22} className="text-accent" />
          </div>
          <h1 className="text-2xl font-bold mb-1 text-white">{title}</h1>
          <p className="text-muted-foreground text-sm mb-6 lg:hidden">{subtitle}</p>
          <p className="text-muted-foreground text-sm mb-6 hidden lg:block">
            Sign in to continue to your {roleLabel.toLowerCase()} dashboard.
          </p>
          {children}
        </Card>
      </div>
    </div>
  </div>
);

export default AuthShell;
