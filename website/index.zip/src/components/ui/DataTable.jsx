// Generic read-only table. Wide tables scroll inside their own container so
// the page body never scrolls sideways.
//   columns: [{ key, label, render?(row), wrap?, className? }]
const DataTable = ({ columns, rows, rowKey, emptyText = "No records found." }) => (
  <div className="overflow-x-auto rounded-2xl border border-line bg-card">
    <table className="w-full text-sm text-left">
      <thead className="bg-surface text-muted-foreground text-xs uppercase tracking-wider">
        <tr>
          {columns.map((col) => (
            <th
              key={col.key}
              className={`px-4 py-3 font-semibold whitespace-nowrap ${col.className || ""}`}
            >
              {col.label}
            </th>
          ))}
        </tr>
      </thead>
      <tbody className="divide-y divide-line">
        {rows.length === 0 ? (
          <tr>
            <td
              colSpan={columns.length}
              className="px-4 py-10 text-center text-muted-foreground"
            >
              {emptyText}
            </td>
          </tr>
        ) : (
          rows.map((row) => (
            <tr key={rowKey(row)} className="hover:bg-white/[0.02] transition-colors">
              {columns.map((col) => (
                <td
                  key={col.key}
                  className={`px-4 py-3 text-white align-top ${
                    col.wrap ? "min-w-[14rem]" : "whitespace-nowrap"
                  } ${col.className || ""}`}
                >
                  {col.render ? col.render(row) : (row[col.key] ?? "—")}
                </td>
              ))}
            </tr>
          ))
        )}
      </tbody>
    </table>
  </div>
);

export default DataTable;
