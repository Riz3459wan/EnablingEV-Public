import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

const Field = ({ label, error, className = "", children }) => (
  <div className={className}>
    {label && (
      <label className="block text-sm font-medium mb-1.5 text-gray-200">
        {label}
      </label>
    )}
    {children}
    {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
  </div>
);

const inputBase =
  "w-full bg-background border rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-placeholder outline-none transition-colors focus:border-accent";

export const Input = ({ error, className = "", ...rest }) => (
  <input
    className={`${inputBase} ${error ? "border-red-500" : "border-line"} ${className}`}
    {...rest}
  />
);

// Password input with a show/hide toggle — used by every login form instead
// of each page re-implementing the eye-icon toggle itself.
export const PasswordInput = ({ error, className = "", ...rest }) => {
  const [visible, setVisible] = useState(false);

  return (
    <div className="relative">
      <input
        type={visible ? "text" : "password"}
        className={`${inputBase} pr-11 ${error ? "border-red-500" : "border-line"} ${className}`}
        {...rest}
      />
      <button
        type="button"
        onClick={() => setVisible((v) => !v)}
        tabIndex={-1}
        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-white transition-colors"
        aria-label={visible ? "Hide password" : "Show password"}
      >
        {visible ? <EyeOff size={17} /> : <Eye size={17} />}
      </button>
    </div>
  );
};

export const Select = ({ error, className = "", children, ...rest }) => (
  <select
    className={`${inputBase} ${error ? "border-red-500" : "border-line"} ${className}`}
    {...rest}
  >
    {children}
  </select>
);

export const Textarea = ({ error, className = "", ...rest }) => (
  <textarea
    className={`${inputBase} resize-none ${error ? "border-red-500" : "border-line"} ${className}`}
    {...rest}
  />
);

export default Field;
