export const PrimaryButton = ({ children, className = "", ...rest }) => (
  <button
    className={`font-display bg-primary hover:bg-primary-hover text-background px-6 py-2.5 rounded-full font-semibold tracking-tight transition-all duration-200 shadow-sm active:scale-[0.98] flex items-center justify-center gap-2 ${className}`}
    {...rest}
  >
    {children}
  </button>
);

export const SecondaryButton = ({ children, className = "", ...rest }) => (
  <button
    className={`font-display bg-card/70 hover:bg-surface text-white border border-line px-6 py-2.5 rounded-full font-semibold tracking-tight transition-all duration-200 active:scale-[0.98] flex items-center justify-center gap-2 ${className}`}
    {...rest}
  >
    {children}
  </button>
);

// Ember variant — the second accent, reserved for one high-stakes moment
// per page (e.g. "Register as a dealer") so it doesn't compete with primary.
export const EmberButton = ({ children, className = "", ...rest }) => (
  <button
    className={`font-display bg-ember hover:brightness-110 text-ember-foreground px-6 py-2.5 rounded-full font-semibold tracking-tight transition-all duration-200 shadow-sm active:scale-[0.98] flex items-center justify-center gap-2 ${className}`}
    {...rest}
  >
    {children}
  </button>
);
