import { Component } from "react";
import { AlertTriangle } from "lucide-react";
import Card from "./Card";
import { SecondaryButton } from "./Button";

// Wraps a role dashboard so one broken widget/tool card can't take down the
// whole page with a blank white screen — shows a recoverable error instead.
class ErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error("Dashboard crashed:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <section className="min-h-screen flex items-center justify-center px-4">
          <Card className="p-8 max-w-md text-center">
            <div className="w-12 h-12 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle size={22} className="text-red-400" />
            </div>
            <h2 className="text-lg font-semibold text-white mb-2">
              Something went wrong
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              This screen hit an unexpected error. Reloading usually fixes it.
            </p>
            <SecondaryButton onClick={() => window.location.reload()}>
              Reload
            </SecondaryButton>
          </Card>
        </section>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
