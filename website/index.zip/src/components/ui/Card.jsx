export const Card = ({ className = "", children }) => (
  <div
    className={`bg-card border border-line rounded-2xl shadow-2xl ${className}`}
  >
    {children}
  </div>
);

export default Card;
