import Card from "./Card";
import { SecondaryButton } from "./Button";

// Skeleton rows instead of a plain spinner — shared by every list page
// (CustomerInfo, DealerInfo, SubAdminInfo, DisplayVehicleInfo, QuotationList),
// so this one change updates the loading state everywhere consistently.
export const LoadingCard = ({ rows = 5 }) => (
  <div className="overflow-hidden rounded-2xl border border-line bg-card">
    <div className="h-10 bg-surface" />
    <div className="divide-y divide-line">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 px-4 py-4">
          <div className="h-3 rounded-full bg-white/5 animate-pulse w-1/4" />
          <div className="h-3 rounded-full bg-white/5 animate-pulse w-1/6" />
          <div className="h-3 rounded-full bg-white/5 animate-pulse w-1/3" />
          <div className="h-3 rounded-full bg-white/5 animate-pulse w-1/5 ml-auto" />
        </div>
      ))}
    </div>
  </div>
);

export const ErrorCard = ({ message, onRetry }) => (
  <Card className="p-8 text-center">
    <p className="text-red-400 text-sm mb-4">{message}</p>
    {onRetry && <SecondaryButton onClick={onRetry}>Retry</SecondaryButton>}
  </Card>
);

export const Banner = ({ type, children }) => (
  <div
    className={`mb-6 px-4 py-3 rounded-xl text-sm border ${
      type === "success"
        ? "bg-accent/10 border-accent/30 text-accent"
        : "bg-red-500/10 border-red-500/30 text-red-400"
    }`}
  >
    {children}
  </div>
);
