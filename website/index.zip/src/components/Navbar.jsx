import { useState, memo } from "react";
import { Menu, X, ChevronDown, LogOut } from "lucide-react";
import { Link, NavLink, useNavigate } from "react-router";
import { PrimaryButton, SecondaryButton } from "./ui/Button";
import { publicLinks, roleLinks } from "../data/navLinks";
import { useAuth } from "../auth/AuthContext";
import BrandMark from "./ui/BrandMark";

const ROLE_LABEL = { subadmin: "Sub Admin", dealer: "Dealer" };
const ROLE_DASH = {
  subadmin: "/subAdminDash",
  dealer: "/dealerDash",
};

const desktopLinkClass = ({ isActive }) =>
  `whitespace-nowrap hover:text-white transition-colors cursor-pointer ${
    isActive ? "text-white" : ""
  }`;

const mobileLinkClass = ({ isActive }) =>
  `text-left text-muted-foreground hover:text-white text-base transition-colors py-1 ${
    isActive ? "text-white" : ""
  }`;

// onOpenDealer is only used for the public top utility-bar "Dealer enquiry" link —
// the "Become a dealer" buttons go straight to real registration (/DealerForm).
const Navbar = memo(({ onOpenDealer }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loginMenuOpen, setLoginMenuOpen] = useState(false);
  const { isLoggedIn, role, logout } = useAuth();
  const navigate = useNavigate();

  // Logged in with a known role => portal navbar. Otherwise the public navbar.
  const isPortal = isLoggedIn && !!roleLinks[role];
  const links = isPortal ? roleLinks[role] : publicLinks;

  // Portal has more links, so it collapses to the hamburger at `xl`, public at `md`.
  // (Full class strings on purpose so Tailwind can see them.)
  const linksRowClass = isPortal
    ? "hidden xl:flex items-center gap-6 text-sm font-medium text-muted-foreground"
    : "hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground";
  const rightRowClass = isPortal
    ? "hidden xl:flex items-center gap-3"
    : "hidden md:flex items-center gap-3";
  const burgerClass = isPortal
    ? "xl:hidden text-muted-foreground hover:text-white p-1"
    : "md:hidden text-muted-foreground hover:text-white p-1";
  const mobilePanelClass = isPortal
    ? "xl:hidden border-t border-border py-5 flex flex-col gap-4 bg-background"
    : "md:hidden border-t border-border py-5 flex flex-col gap-4 bg-background";

  const closeMobile = () => setMobileOpen(false);

  const handleLogout = () => {
    const loginPath = {
      subadmin: "/subAdminLogin",
      dealer: "/dealerLogin",
    }[role];
    logout();
    setMobileOpen(false);
    navigate(loginPath || "/");
  };

  return (
    <header className="fixed w-full z-50 top-0">
      <div className="bg-[#040e0f] border-b border-[#0f2427] text-xs text-muted-foreground py-1.5 px-4 sm:px-6 lg:px-8 hidden md:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-accent inline-block"></span>
            {isPortal ? (
              <span>{ROLE_LABEL[role]} portal</span>
            ) : (
              <span>India-ready electric mobility</span>
            )}
            <span className="text-line">•</span>
            <span>Enabling E-Vehicle Private Limited</span>
          </div>
          {isPortal ? (
            <Link
              to="/"
              className="text-accent hover:underline flex items-center gap-1 transition-colors"
            >
              View public site →
            </Link>
          ) : (
            <button
              onClick={onOpenDealer}
              className="text-accent hover:underline flex items-center gap-1 transition-colors"
            >
              Dealer enquiry →
            </button>
          )}
        </div>
      </div>

      <nav className="border-b border-surface bg-background/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link
              to={isPortal ? ROLE_DASH[role] : "/"}
              className="flex items-center gap-2.5 cursor-pointer text-white"
            >
              <BrandMark className="h-9 w-auto" />
              <span className="font-display font-semibold text-xl tracking-tight text-white">
                Enabling<span className="text-accent">EV</span>
              </span>
            </Link>

            <div className={linksRowClass}>
              {links.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === "/"}
                  className={desktopLinkClass}
                >
                  {link.label}
                </NavLink>
              ))}
            </div>

            <div className={rightRowClass}>
              {isPortal ? (
                <>
                  <span className="text-xs font-semibold text-accent border border-line bg-card/80 rounded-full px-3 py-1.5">
                    {ROLE_LABEL[role]}
                  </span>
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-1.5 text-xs font-semibold text-destructive border border-destructive/30 bg-destructive/10 hover:bg-destructive/20 hover:border-destructive/50 rounded-full px-3 py-1.5 transition-colors"
                  >
                    <LogOut size={13} /> Logout
                  </button>
                </>
              ) : (
                <>
                  <SecondaryButton
                    className="!py-2 !px-5 text-sm !rounded-full !border-ember/30 !text-ember hover:!bg-ember/10"
                    onClick={() => navigate("/DealerForm")}
                  >
                    Become a dealer
                  </SecondaryButton>

                  <div className="relative">
                    <PrimaryButton
                      className="!py-2 !px-5 text-sm !rounded-full !bg-primary hover:!bg-primary-hover !text-background font-semibold"
                      onClick={() => setLoginMenuOpen((v) => !v)}
                    >
                      Login Portal <ChevronDown size={16} />
                    </PrimaryButton>
                    {loginMenuOpen && (
                      <>
                        <div
                          className="fixed inset-0 z-10"
                          onClick={() => setLoginMenuOpen(false)}
                        />
                        <div className="absolute right-0 mt-2 w-40 bg-card border border-line rounded-xl shadow-2xl overflow-hidden z-20">
                          {[
                            { label: "Sub Admin", to: "/subAdminLogin" },
                            { label: "Dealer", to: "/dealerLogin" },
                          ].map((item) => (
                            <Link
                              key={item.to}
                              to={item.to}
                              onClick={() => setLoginMenuOpen(false)}
                              className="block px-4 py-2.5 text-sm text-muted-foreground hover:text-white hover:bg-surface transition-colors"
                            >
                              {item.label}
                            </Link>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                </>
              )}
            </div>

            <button
              className={burgerClass}
              onClick={() => setMobileOpen((v) => !v)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {mobileOpen && (
            <div className={mobilePanelClass}>
              {isPortal && (
                <span className="text-xs font-semibold uppercase tracking-wider text-accent">
                  {ROLE_LABEL[role]} portal
                </span>
              )}
              {links.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === "/"}
                  onClick={closeMobile}
                  className={mobileLinkClass}
                >
                  {link.label}
                </NavLink>
              ))}
              <div className="flex flex-col gap-3 pt-3 border-t border-surface">
                {isPortal ? (
                  <>
                    <Link
                      to="/"
                      onClick={closeMobile}
                      className="text-center text-sm text-accent py-2"
                    >
                      View public site →
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center justify-center gap-1.5 text-sm font-semibold text-destructive border border-destructive/30 bg-destructive/10 rounded-full py-2.5"
                    >
                      <LogOut size={15} /> Logout ({ROLE_LABEL[role]})
                    </button>
                  </>
                ) : (
                  <>
                    <SecondaryButton
                      className="w-full justify-center !border-ember/30 !text-ember hover:!bg-ember/10"
                      onClick={() => {
                        setMobileOpen(false);
                        navigate("/DealerForm");
                      }}
                    >
                      Become a dealer
                    </SecondaryButton>
                    <div className="grid grid-cols-2 gap-2">
                      <Link
                        to="/subAdminLogin"
                        onClick={closeMobile}
                        className="text-center text-xs text-muted-foreground border border-line rounded-full py-2"
                      >
                        Sub Admin
                      </Link>
                      <Link
                        to="/dealerLogin"
                        onClick={closeMobile}
                        className="text-center text-xs text-muted-foreground border border-line rounded-full py-2"
                      >
                        Dealer
                      </Link>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
});

export default Navbar;
