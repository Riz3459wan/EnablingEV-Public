import aboutImg from "../../assets/about/about.webp";

const About = () => (
  <section className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
    <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
      <div>
        <div className="flex items-center gap-2.5 mb-5">
          <span className="h-px w-8 bg-accent" />
          <span className="text-sm text-muted-foreground">Welcome to</span>
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-6 leading-tight text-balance">
          Enabling E-Vehicle Pvt. Ltd.
        </h1>
        <p className="text-muted-foreground text-base sm:text-lg leading-relaxed">
          Welcome to Enabling E-Vehicle Pvt. Ltd., a pioneering force in the
          realm of eco-friendly transportation solutions. Our commitment to
          innovation and sustainability is embodied in our flagship product,
          the JHATPAT JIO electric rickshaw.
        </p>
        <p className="text-muted-foreground text-base sm:text-lg leading-relaxed mt-4">
          Founded with a vision to transform urban mobility, Enabling
          E-Vehicle stands at the forefront of the electric vehicle
          revolution. Our journey began in 2013, driven by a passion for
          creating advanced transportation solutions that not only enhance
          the commuting experience but also contribute to a greener planet.
        </p>
        <p className="text-muted-foreground text-base sm:text-lg leading-relaxed mt-4">
          At Enabling E-Vehicle, we believe transportation should be
          efficient, reliable, and environmentally responsible. The JHATPAT
          JIO electric rickshaw is a testament to our dedication to these
          values — a seamless blend of performance, comfort and
          sustainability.
        </p>
      </div>

      <div className="rounded-2xl overflow-hidden border border-border">
        <img
          src={aboutImg}
          alt="Enabling EV electric rickshaw"
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  </section>
);

export default About;
