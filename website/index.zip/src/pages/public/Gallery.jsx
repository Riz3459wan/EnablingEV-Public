import { useState } from "react";
import galleryImages from "../../data/galleryImages";
import instagramReels from "../../data/instagramReels";
import Lightbox from "../../components/ui/Lightbox";
import InstagramEmbed from "../../components/ui/InstagramEmbed";
import { PrimaryButton, SecondaryButton } from "../../components/ui/Button";
import Card from "../../components/ui/Card";
import { SocialIcon } from "../../components/ui/SocialIcons";
import { SOCIALS } from "../../data/company";

const Gallery = () => {
  const [showAll, setShowAll] = useState(false);
  const [selectedImg, setSelectedImg] = useState(null);
  const instagramProfile = SOCIALS.find((s) => s.name === "instagram");

  const visibleImages = showAll ? galleryImages : galleryImages.slice(0, 4);

  return (
    <section className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-2.5 mb-4">
          <span className="h-px w-8 bg-accent" />
          <span className="text-sm text-muted-foreground">Our gallery</span>
          <span className="h-px w-8 bg-accent" />
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mb-4">
          Moments from the road
        </h1>
        <p className="text-muted-foreground max-w-xl mx-auto">
          Explore our collection of electric rickshaws and memorable moments.
          Click any photo to view it in full size.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {visibleImages.map((img, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedImg(img)}
            className="rounded-2xl overflow-hidden border border-border bg-card hover:scale-[1.03] transition-transform"
          >
            <img
              src={img}
              alt={`Gallery photo ${idx + 1}`}
              className="w-full h-48 sm:h-56 object-cover"
              loading="lazy"
            />
          </button>
        ))}
      </div>

      {galleryImages.length > 4 && (
        <div className="flex justify-center mt-8">
          {showAll ? (
            <SecondaryButton onClick={() => setShowAll(false)}>See less</SecondaryButton>
          ) : (
            <PrimaryButton onClick={() => setShowAll(true)}>Show more</PrimaryButton>
          )}
        </div>
      )}

      {/* Video highlights */}
      <div className="mt-20 grid lg:grid-cols-3 gap-6 items-stretch">
        {/* YouTube — wide, takes the majority of the row */}
        <Card className="lg:col-span-2 p-6 sm:p-10 text-center flex flex-col">
          <p className="text-accent text-sm font-medium mb-3">
            🎬 Highlights
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">
            Watch our journey
          </h2>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            Stories and highlights from the road, straight from our channel.
          </p>
          <div className="rounded-2xl overflow-hidden border border-border mt-auto">
            <iframe
              width="100%"
              height="400"
              src="https://www.youtube.com/embed?listType=playlist&list=UUh0Sj3fpFAoUys8Vckkwspg"
              title="YouTube Channel Uploads"
              className="block"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </Card>

        {/* Instagram reels — narrower column, vertical reels stack/scroll */}
        <Card className="p-6 sm:p-8 text-center flex flex-col">
          <p className="text-accent text-sm font-medium mb-3">
            📸 Reels
          </p>
          <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">
            On Instagram
          </h2>
          <p className="text-muted-foreground mb-6 text-sm max-w-xs mx-auto">
            Quick clips and behind-the-scenes moments from our page.
          </p>

          {instagramReels.length > 0 ? (
            <div className="flex-1 space-y-4 max-h-[520px] overflow-y-auto pr-1">
              {instagramReels.map((url) => (
                <div
                  key={url}
                  className="rounded-2xl overflow-hidden border border-border bg-background"
                >
                  <InstagramEmbed url={url} />
                </div>
              ))}
            </div>
          ) : (
            instagramProfile && (
              <a
                href={instagramProfile.href}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-auto flex flex-col items-center justify-center gap-3 rounded-2xl border border-border bg-background py-10 px-4 hover:border-accent/50 transition-colors"
              >
                <span className="w-12 h-12 rounded-full bg-surface border border-border flex items-center justify-center text-accent">
                  <SocialIcon name="instagram" size={22} />
                </span>
                <span className="text-sm text-white font-medium">
                  Follow us on Instagram
                </span>
                <span className="text-xs text-muted-foreground">
                  for reels &amp; behind-the-scenes
                </span>
              </a>
            )
          )}
        </Card>
      </div>

      {/* Social */}
      <div className="mt-16 text-center">
        <h2 className="text-xl font-bold text-white mb-1">Connect with us</h2>
        <p className="text-muted-foreground mb-6">
          Visit our social pages to explore more and stay updated.
        </p>
        <div className="flex justify-center gap-4">
          {SOCIALS.map(({ name, href, label }) => (
            <a
              key={name}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={label}
              className="w-14 h-14 rounded-full bg-surface border border-border flex items-center justify-center text-accent hover:bg-surface hover:scale-105 transition-all"
            >
              <SocialIcon name={name} size={24} />
            </a>
          ))}
        </div>
      </div>

      <Lightbox src={selectedImg} onClose={() => setSelectedImg(null)} />
    </section>
  );
};

export default Gallery;
