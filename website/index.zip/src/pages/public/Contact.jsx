import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";
import { MapPin, Phone, Mail } from "lucide-react";
import api from "../../api/client";
import Card from "../../components/ui/Card";
import Field, { Input } from "../../components/ui/Field";
import { PrimaryButton } from "../../components/ui/Button";
import { OFFICES, PHONES, EMAIL } from "../../data/company";

// Vite bundles these differently to CRA's require() — fix default marker icon once
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const generateCaptcha = () =>
  Math.floor(1000 + Math.random() * 9000).toString();

const Contact = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    contact: "",
    address: "",
    pincode: "",
    state: "",
    district: "",
    captcha: "",
  });
  const [captchaValue, setCaptchaValue] = useState(generateCaptcha());
  const [captchaError, setCaptchaError] = useState(false);
  const [status, setStatus] = useState("idle");

  // Rotate captcha every minute, same as old app
  useEffect(() => {
    const interval = setInterval(
      () => setCaptchaValue(generateCaptcha()),
      60000,
    );
    return () => clearInterval(interval);
  }, []);

  const update = (field) => (e) => {
    let { value } = e.target;
    if (field === "name") value = value.replace(/[^a-zA-Z\s]/g, "");
    if (field === "contact") value = value.replace(/[^0-9]/g, "").slice(0, 10);
    setForm((f) => ({ ...f, [field]: value }));
  };

  // Pincode -> state/district autofill. `cancelled` drops the response if the
  // pincode changed (or the page closed) before it came back.
  useEffect(() => {
    if (form.pincode.length !== 6) return undefined;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `https://api.postalpincode.in/pincode/${form.pincode}`,
        );
        const data = (await res.json())[0];
        if (!cancelled && data.Status === "Success") {
          const { State, District } = data.PostOffice[0];
          setForm((f) => ({ ...f, state: State, district: District }));
        }
      } catch {
        // Non-critical enrichment — silently ignore, user can still submit
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [form.pincode]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.captcha !== captchaValue) {
      setCaptchaError(true);
      return;
    }
    setCaptchaError(false);
    setStatus("submitting");
    try {
      await api.post("/contact", form);
      setStatus("success");
    } catch {
      setStatus("error");
    }
  };

  return (
    <section className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Company details + map */}
        <Card className="p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-white mb-6">
            Company details
          </h2>
          <div className="space-y-4 mb-6">
            {OFFICES.map((office) => (
              <div key={office.label} className="flex gap-3">
                <MapPin size={18} className="text-accent shrink-0 mt-0.5" />
                <p className="text-sm text-muted-foreground">
                  <strong className="text-white">{office.label}:</strong>{" "}
                  {office.address}
                </p>
              </div>
            ))}
            <div className="flex gap-3">
              <Phone size={18} className="text-accent shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                {PHONES.map((p) => p.display).join(", ")}
              </p>
            </div>
            <div className="flex gap-3">
              <Mail size={18} className="text-accent shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">{EMAIL}</p>
            </div>
          </div>

          {/* relative z-0 added here to prevent Leaflet from overlapping navbar */}
          <div className="relative z-0 rounded-2xl overflow-hidden border border-border h-[300px]">
            <MapContainer
              center={OFFICES[0].coords}
              zoom={6}
              style={{ height: "100%", width: "100%" }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              {OFFICES.map((office) => (
                <Marker key={office.label} position={office.coords}>
                  <Popup>{office.address}</Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        </Card>

        {/* Contact form */}
        <Card className="p-6 sm:p-8">
          <h2 className="text-2xl font-bold text-white mb-6">Contact form</h2>

          {status === "success" ? (
            <p className="text-accent">
              Thanks! We've received your message and will get back to you soon.
            </p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              <Field label="Name">
                <Input
                  value={form.name}
                  onChange={update("name")}
                  placeholder="Letters and spaces only"
                  required
                />
              </Field>
              <Field label="Email">
                <Input
                  type="email"
                  value={form.email}
                  onChange={update("email")}
                  placeholder="you@example.com"
                  required
                />
              </Field>
              <Field label="Contact number">
                <Input
                  value={form.contact}
                  onChange={update("contact")}
                  placeholder="10-digit number"
                  required
                />
              </Field>
              <Field label="Address">
                <Input
                  value={form.address}
                  onChange={update("address")}
                  placeholder="Your address"
                  required
                />
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Pincode">
                  <Input
                    value={form.pincode}
                    onChange={update("pincode")}
                    placeholder="6-digit pincode"
                    maxLength={6}
                    required
                  />
                </Field>
                <Field label="State / District">
                  <Input
                    value={[form.district, form.state]
                      .filter(Boolean)
                      .join(", ")}
                    readOnly
                    placeholder="Auto-filled from pincode"
                  />
                </Field>
              </div>
              <Field
                label={`Captcha (enter: ${captchaValue})`}
                error={captchaError ? "Captcha does not match." : null}
              >
                <Input
                  value={form.captcha}
                  onChange={update("captcha")}
                  placeholder="Enter the captcha above"
                  required
                />
              </Field>
              {status === "error" && (
                <p className="text-amber-300 text-xs bg-amber-400/10 border border-amber-400/20 rounded-lg px-3 py-2">
                  Something went wrong submitting the form. Please try again.
                </p>
              )}
              <PrimaryButton
                type="submit"
                disabled={status === "submitting"}
                className="w-full justify-center"
              >
                {status === "submitting" ? "Submitting..." : "Submit"}
              </PrimaryButton>
            </form>
          )}
        </Card>
      </div>
    </section>
  );
};

export default Contact;
