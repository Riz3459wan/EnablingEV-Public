import Hero from "../../sections/Hero";
import CarouselSection from "../../sections/CarouselSection";
import VehiclesSection from "../../sections/VehiclesSection";
import MissionSection from "../../sections/MissionSection";
import GallerySection from "../../sections/GallerySection";
import DealerSection from "../../sections/DealerSection";
import { useModal } from "../../context/ModalContext";
import scrollToId from "../../utils/scrollToId";

const Home = () => {
  const { openVehicleEnquiry } = useModal();

  return (
    <>
      <CarouselSection />
      <Hero onExplore={() => scrollToId("vehicles")} />
      <VehiclesSection onEnquire={openVehicleEnquiry} />
      <MissionSection />
      <GallerySection />
      <DealerSection />
    </>
  );
};

export default Home;
