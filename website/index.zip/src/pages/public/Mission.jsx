import MissionSection from "../../sections/MissionSection";

const Mission = () => (
  <div className="pt-16">
    <MissionSection />
  </div>
);

export default Mission;
