import { useState } from "react";
import { ChevronLeft, ChevronRight, BatteryFull } from "lucide-react";
import products, { colorMap } from "../../data/products";
import Lightbox from "../../components/ui/Lightbox";
import Card from "../../components/ui/Card";
import { PrimaryButton, SecondaryButton } from "../../components/ui/Button";
import { useModal } from "../../context/ModalContext";

const FEATURE_PREVIEW_COUNT = 6;

const ProductCard = ({ product, onEnquire }) => {
  const [mainImage, setMainImage] = useState(product.images[0]);
  const [zoomImg, setZoomImg] = useState(null);
  const [showAllFeatures, setShowAllFeatures] = useState(false);
  const [showAllAccessories, setShowAllAccessories] = useState(false);

  const step = (dir) => {
    const idx = product.images.indexOf(mainImage);
    const next = (idx + dir + product.images.length) % product.images.length;
    setMainImage(product.images[next]);
  };

  const visibleFeatures = showAllFeatures
    ? product.features
    : product.features.slice(0, FEATURE_PREVIEW_COUNT);
  const visibleAccessories = showAllAccessories
    ? product.accessories
    : product.accessories.slice(0, FEATURE_PREVIEW_COUNT);

  return (
    <Card className="p-6 sm:p-8">
      <div className="grid lg:grid-cols-2 gap-10">
        {/* Gallery */}
        <div>
          <div className="relative rounded-2xl overflow-hidden border border-border bg-surface aspect-[4/3]">
            <img
              src={mainImage}
              alt={product.name}
              onClick={() => setZoomImg(mainImage)}
              className="w-full h-full object-contain cursor-zoom-in"
            />
            <button
              onClick={() => step(-1)}
              className="absolute left-3 top-1/2 -translate-y-1/2 bg-background/80 border border-border rounded-full p-2 text-white hover:bg-surface"
              aria-label="Previous image"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={() => step(1)}
              className="absolute right-3 top-1/2 -translate-y-1/2 bg-background/80 border border-border rounded-full p-2 text-white hover:bg-surface"
              aria-label="Next image"
            >
              <ChevronRight size={18} />
            </button>
          </div>
          <div className="flex gap-3 mt-4">
            {product.images.map((img, i) => (
              <button
                key={i}
                onClick={() => setMainImage(img)}
                className={`w-16 h-16 rounded-lg overflow-hidden border transition-colors ${
                  mainImage === img ? "border-accent" : "border-border"
                }`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Details */}
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">{product.name}</h2>

          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-5">
            <BatteryFull size={18} className="text-accent" />
            <span>Battery options:</span>
            <span className="text-white font-medium">
              {product.batteryOptions.join(" / ")}
            </span>
          </div>

          <div className="mb-6">
            <p className="text-xs font-semibold tracking-wider uppercase text-muted-foreground mb-2">
              Colors
            </p>
            <div className="flex gap-2 flex-wrap">
              {product.colors.map((c) => (
                <span
                  key={c.value}
                  title={c.label}
                  className="w-8 h-8 rounded-full border border-border"
                  style={{ backgroundColor: colorMap[c.value] }}
                />
              ))}
            </div>
          </div>

          <div className="mb-6">
            <p className="text-xs font-semibold tracking-wider uppercase text-muted-foreground mb-3">
              Features
            </p>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-sm text-muted-foreground">
              {visibleFeatures.map((f) => (
                <li key={f} className="flex gap-2">
                  <span className="text-accent">•</span> {f}
                </li>
              ))}
            </ul>
            {product.features.length > FEATURE_PREVIEW_COUNT && (
              <button
                onClick={() => setShowAllFeatures((v) => !v)}
                className="text-accent text-sm mt-2 hover:underline"
              >
                {showAllFeatures ? "Show less" : `+${product.features.length - FEATURE_PREVIEW_COUNT} more`}
              </button>
            )}
          </div>

          <div className="mb-8">
            <p className="text-xs font-semibold tracking-wider uppercase text-muted-foreground mb-3">
              Accessories included
            </p>
            <div className="flex flex-wrap gap-2">
              {visibleAccessories.map((a) => (
                <span
                  key={a}
                  className="text-xs bg-surface border border-border rounded-full px-3 py-1.5 text-muted-foreground"
                >
                  {a}
                </span>
              ))}
              {product.accessories.length > FEATURE_PREVIEW_COUNT && (
                <button
                  onClick={() => setShowAllAccessories((v) => !v)}
                  className="text-accent text-xs hover:underline"
                >
                  {showAllAccessories ? "Show less" : "Show all"}
                </button>
              )}
            </div>
          </div>

          <div className="flex gap-3">
            <PrimaryButton onClick={() => onEnquire(product.name)}>Enquire now</PrimaryButton>
            <SecondaryButton onClick={() => setZoomImg(mainImage)}>View full image</SecondaryButton>
          </div>
        </div>
      </div>

      <Lightbox src={zoomImg} onClose={() => setZoomImg(null)} />
    </Card>
  );
};

const Product = () => {
  const { openVehicleEnquiry } = useModal();

  return (
    <section className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-2.5 mb-4">
          <span className="h-px w-8 bg-accent" />
          <span className="text-sm text-muted-foreground">Our products</span>
          <span className="h-px w-8 bg-accent" />
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white">
          Built for every route
        </h1>
      </div>

      <div className="flex flex-col gap-12">
        {products.map((product) => (
          <ProductCard key={product.name} product={product} onEnquire={openVehicleEnquiry} />
        ))}
      </div>
    </section>
  );
};

export default Product;
