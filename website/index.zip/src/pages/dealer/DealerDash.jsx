import { Link, useNavigate } from "react-router";
import {
  UserPlus,
  ClipboardList,
  Truck,
  FileText,
  FileCheck2,
  Phone,
  TriangleAlert,
} from "lucide-react";
import { useDealerInfo } from "../../auth/useDealerInfo";
import Card from "../../components/ui/Card";
import DealerForm22 from "../../components/dealer/DealerForm22";

// Migrated from the old app's pages/dealerDash/DealerDash.jsx. The old page
// mounted five full components inline inside one MUI grid. Here it's a
// navigation hub (same pattern as AdminDash): each tool has its own route.
// Only Form 22 stays embedded — DealerForm22 was written as a self-contained
// card body for exactly this spot.
// Flip `ready` to true when the target page is migrated off ComingSoon.
const tools = [
  {
    to: "/customerForm",
    icon: UserPlus,
    title: "Add Customer",
    description: "Register a customer against a chassis number.",
    ready: true,
  },
  {
    to: "/dealerCustomerInfo",
    icon: ClipboardList,
    title: "My Customers",
    description: "Search and review your customer records.",
    ready: true,
  },
  {
    to: "/displayVehicleInfo",
    icon: Truck,
    title: "Vehicles",
    description: "Track vehicles assigned to your dealership.",
    ready: true,
  },
  {
    to: "/createQuotation",
    icon: FileText,
    title: "Create Quotation",
    description: "Prepare and manage quotations for your customers.",
    ready: true,
  },
];

const DealerDash = () => {
  const { dealerInfo, dealerCode } = useDealerInfo();
  const navigate = useNavigate();

  const name = dealerInfo?.name || "Dealer";
  const initial = name.charAt(0).toUpperCase();
  const mobile = dealerInfo?.mobileNo || dealerInfo?.mobileNumber;

  return (
    <section className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-5xl mx-auto">
        <div className="mb-8">
          <span className="text-xs uppercase tracking-widest font-semibold text-accent mb-1 inline-block">
            Dealer
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Dealer Dashboard
          </h1>
        </div>

        <Card className="p-5 sm:p-6 mb-6">
          <div className="flex items-center gap-4">
            <div className="shrink-0 w-14 h-14 rounded-full bg-accent/10 border border-accent/30 flex items-center justify-center text-xl font-bold text-accent">
              {initial}
            </div>
            <div className="min-w-0">
              <p className="text-lg font-bold text-white truncate">{name}</p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                <span>
                  Dealer code:{" "}
                  <span className="text-white font-mono">
                    {dealerCode || "N/A"}
                  </span>
                </span>
                {mobile && (
                  <span className="flex items-center gap-1.5">
                    <Phone size={13} /> {mobile}
                  </span>
                )}
              </div>
            </div>
          </div>
          {!dealerCode && (
            <p className="mt-4 flex items-start gap-2 text-amber-300 text-xs bg-amber-400/10 border border-amber-400/20 rounded-lg px-3 py-2 leading-relaxed">
              <TriangleAlert size={14} className="mt-0.5 shrink-0" />
              Dealer code not found for this session. Some tools need it —
              please log out and sign in again.
            </p>
          )}
        </Card>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {tools.map(({ to, icon: Icon, title, description, ready }) =>
            ready ? (
              <Link
                key={to}
                to={to}
                className="group p-6 rounded-3xl bg-card border border-line hover:border-accent/50 transition-all"
              >
                <div className="w-11 h-11 rounded-xl bg-accent/10 border border-accent/30 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Icon size={20} className="text-accent" />
                </div>
                <h2 className="font-semibold text-white mb-1">{title}</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {description}
                </p>
              </Link>
            ) : (
              <Card
                key={to}
                className="p-6 border border-white/5 opacity-60 cursor-not-allowed"
              >
                <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
                  <Icon size={20} className="text-muted-foreground" />
                </div>
                <h2 className="font-semibold text-white mb-1">{title}</h2>
                <p className="text-sm text-muted-foreground leading-relaxed mb-2">
                  {description}
                </p>
                <span className="text-[10px] uppercase tracking-wider font-semibold text-placeholder">
                  Coming soon
                </span>
              </Card>
            ),
          )}

          <Card className="p-6 sm:col-span-2 lg:col-span-2">
            <DealerForm22 dealerCode={dealerCode} />
          </Card>

          {/* NEW — the old app showed this right after registration
             (dealerCode/mobileNo were assigned immediately). Under the new
             approval flow there's no longer a single moment right after
             signup to show it, so it's surfaced here instead: otherwise the
             "Get Certificate" combined LOI/Certificate/Request-Letter PDF
             (Document.jsx, content unchanged from the old app) was never
             reachable from any screen. */}
          <button
            type="button"
            onClick={() =>
              navigate("/document", { state: { submittedData: dealerInfo } })
            }
            disabled={!dealerInfo}
            className="group p-6 rounded-3xl bg-card border border-line hover:border-accent/50 transition-all text-left disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:border-line"
          >
            <div className="w-11 h-11 rounded-xl bg-accent/10 border border-accent/30 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
              <FileCheck2 size={20} className="text-accent" />
            </div>
            <h2 className="font-semibold text-white mb-1">
              Download Certificate
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {dealerInfo
                ? "Get your Letter of Intent, Authorization Certificate & RTO Request Letter as one PDF."
                : "Dealer profile not loaded yet — log out and sign in again."}
            </p>
          </button>
        </div>
      </div>
    </section>
  );
};

export default DealerDash;
