import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { KeyRound, Loader2 } from "lucide-react";
import api from "../../api/client";
import { useAuth } from "../../auth/AuthContext";
import AuthShell from "../../components/layout/AuthShell";
import Field, { Input } from "../../components/ui/Field";
import { PrimaryButton } from "../../components/ui/Button";

// Completes registration for a dealer whose request was approved by
// admin. The dealer got an activation code by email (see
// PendingDealerRequests.jsx -> approve); entering it here, along with the
// mobile number they registered with, finishes account setup and logs
// them straight into the dashboard — same shape as DealerLogin.jsx.
const DealerActivate = () => {
  const [activationCode, setActivationCode] = useState("");
  const [mobileNo, setMobileNo] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      const response = await api.post("/dealer/activate", {
        activationCode: activationCode.trim(),
        mobileNo,
      });
      if (response.status === 200) {
        const dealerInfo = response.data?.dealer || null;
        if (dealerInfo) {
          localStorage.setItem("dealerInfo", JSON.stringify(dealerInfo));
        }
        login(response.data?.token || "dealer-auth-token", "dealer");
        navigate("/dealerDash", {
          state: { dealerCode: dealerInfo?.dealerCode },
        });
      }
    } catch (err) {
      if (err.response?.status === 401 || err.response?.status === 404) {
        setError(
          "Invalid or expired activation code, or the mobile number doesn't match our records.",
        );
      } else if (err.response?.status === 409) {
        setError(
          "This account has already been activated. Please sign in instead.",
        );
      } else {
        setError("Something went wrong while activating your account.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthShell
      icon={KeyRound}
      roleLabel="Dealer"
      title="Complete your registration"
      subtitle="Enter the activation code we emailed you after admin approval to finish setting up your dealer account."
      bullets={[
        "One-time step after your request is approved",
        "Confirms your account and unlocks the dashboard",
        "Uses the mobile number from your registration",
      ]}
    >
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Field label="Activation code">
          <Input
            autoFocus
            value={activationCode}
            onChange={(e) => setActivationCode(e.target.value)}
            placeholder="e.g. ACT-98421"
            required
          />
        </Field>
        <Field label="Mobile number">
          <Input
            type="tel"
            value={mobileNo}
            onChange={(e) =>
              setMobileNo(e.target.value.replace(/[^0-9]/g, "").slice(0, 10))
            }
            placeholder="Number used during registration"
            required
          />
        </Field>
        {error && (
          <p className="text-amber-300 text-xs bg-amber-400/10 border border-amber-400/20 rounded-lg px-3 py-2 leading-relaxed">
            {error}
          </p>
        )}
        <PrimaryButton
          type="submit"
          disabled={submitting}
          className="w-full justify-center"
        >
          {submitting ? (
            <>
              <Loader2 size={18} className="animate-spin" /> Activating...
            </>
          ) : (
            "Activate account"
          )}
        </PrimaryButton>
        <Link
          to="/dealerLogin"
          className="block text-center text-sm text-muted-foreground hover:text-accent transition-colors pt-1"
        >
          Already activated?{" "}
          <span className="underline decoration-line underline-offset-4">
            Sign in here →
          </span>
        </Link>
        <Link
          to="/DealerForm"
          className="block text-center text-sm text-muted-foreground hover:text-accent transition-colors"
        >
          Haven't registered yet?{" "}
          <span className="underline decoration-line underline-offset-4">
            Submit a dealer request →
          </span>
        </Link>
        <Link
          to="/dealerStatus"
          className="block text-center text-sm text-muted-foreground hover:text-accent transition-colors"
        >
          Don't have a code yet?{" "}
          <span className="underline decoration-line underline-offset-4">
            Check your request status →
          </span>
        </Link>
      </form>
    </AuthShell>
  );
};

export default DealerActivate;
