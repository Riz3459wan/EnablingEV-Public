import { useState } from "react";
import { Link } from "react-router";
import { Search, Loader2, Clock, CheckCircle2, XCircle } from "lucide-react";
import api from "../../api/client";
import AuthShell from "../../components/layout/AuthShell";
import Field, { Input } from "../../components/ui/Field";
import { PrimaryButton } from "../../components/ui/Button";

// NEW page — a self-service status check for a dealer who already
// submitted DealerForm.jsx and left. Before this, the only way to find out
// whether a request was approved/rejected was to contact admin directly.
// Uses a placeholder endpoint (GET /dealer/status?mobileNo=...), same
// approach as the rest of this registration flow (DealerForm/
// PendingDealerRequests/DealerActivate) which already call placeholder
// endpoints pending the real backend.
const STATES = {
  pending: {
    icon: Clock,
    color: "text-yellow-400 bg-yellow-500/10 border-yellow-500/30",
    title: "Still under review",
    body: "Your registration request hasn't been reviewed yet. Check back later, or wait for our email once a decision is made.",
  },
  approved: {
    icon: CheckCircle2,
    color: "text-accent bg-accent/10 border-accent/30",
    title: "Approved",
    body: "Your request was approved. We've emailed you an activation code — enter it on the activation page to finish setting up your account.",
  },
  rejected: {
    icon: XCircle,
    color: "text-red-400 bg-red-500/10 border-red-500/30",
    title: "Not approved",
    body: "Your request wasn't approved this time. You're welcome to review the details and submit a new request.",
  },
};

const DealerStatus = () => {
  const [mobileNo, setMobileNo] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null); // { status, reason }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setResult(null);
    setSubmitting(true);
    try {
      const res = await api.get("/dealer/status", { params: { mobileNo } });
      const status = (res.data?.status || "").toLowerCase();
      if (!STATES[status]) {
        setError("No registration request found for this mobile number.");
      } else {
        setResult({ status, reason: res.data?.reason });
      }
    } catch (err) {
      if (err.response?.status === 404) {
        setError("No registration request found for this mobile number.");
      } else {
        setError("Something went wrong while checking your status.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const state = result ? STATES[result.status] : null;
  const StateIcon = state?.icon;

  return (
    <AuthShell
      icon={Search}
      roleLabel="Dealer"
      title="Check your request status"
      subtitle="See whether your dealer registration is still pending, approved, or was not approved."
      bullets={[
        "Uses the mobile number from your registration",
        "No login required for this check",
        "Approved? Head to the activation page next",
      ]}
    >
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Field label="Mobile number">
          <Input
            type="tel"
            autoFocus
            value={mobileNo}
            onChange={(e) => {
              setMobileNo(e.target.value.replace(/[^0-9]/g, "").slice(0, 10));
              setResult(null);
              setError("");
            }}
            placeholder="Number used during registration"
            required
          />
        </Field>

        {error && (
          <p className="text-amber-300 text-xs bg-amber-400/10 border border-amber-400/20 rounded-lg px-3 py-2 leading-relaxed">
            {error}
          </p>
        )}

        {state && (
          <div className={`rounded-xl border px-4 py-3 ${state.color}`}>
            <div className="flex items-center gap-2 font-semibold text-sm mb-1">
              <StateIcon size={16} /> {state.title}
            </div>
            <p className="text-xs leading-relaxed opacity-90">{state.body}</p>
            {result.status === "rejected" && result.reason && (
              <p className="text-xs leading-relaxed opacity-90 mt-2">
                <span className="font-medium">Reason:</span> {result.reason}
              </p>
            )}
          </div>
        )}

        <PrimaryButton
          type="submit"
          disabled={submitting || mobileNo.length !== 10}
          className="w-full justify-center"
        >
          {submitting ? (
            <>
              <Loader2 size={18} className="animate-spin" /> Checking...
            </>
          ) : (
            "Check status"
          )}
        </PrimaryButton>

        {result?.status === "approved" && (
          <Link
            to="/dealerActivate"
            className="block text-center text-sm text-accent hover:underline pt-1"
          >
            Enter my activation code →
          </Link>
        )}
        {result?.status === "rejected" && (
          <Link
            to="/DealerForm"
            className="block text-center text-sm text-accent hover:underline pt-1"
          >
            Submit a new request →
          </Link>
        )}
        <Link
          to="/dealerLogin"
          className="block text-center text-sm text-muted-foreground hover:text-accent transition-colors pt-1"
        >
          Already activated?{" "}
          <span className="underline decoration-line underline-offset-4">
            Sign in here →
          </span>
        </Link>
      </form>
    </AuthShell>
  );
};

export default DealerStatus;
