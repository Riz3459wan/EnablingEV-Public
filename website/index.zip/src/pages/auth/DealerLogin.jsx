import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { Store, Loader2 } from "lucide-react";
// eslint-disable-next-line no-unused-vars -- mock login: needed again when the real API call is restored
import api from "../../api/client";
import { useAuth } from "../../auth/AuthContext";
import AuthShell from "../../components/layout/AuthShell";
import Field, { Input, PasswordInput } from "../../components/ui/Field";
import { PrimaryButton } from "../../components/ui/Button";

const DealerLogin = () => {
  const [dealerCode, setDealerCode] = useState("");
  const [mobileNo, setMobileNo] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      // ==============================
      // MOCK / HARDCODED LOGIN
      // ==============================

      const MOCK_DEALER_CODE = "dealer";
      const MOCK_MOBILE_NO = "dealer123";

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 800));

      if (dealerCode === MOCK_DEALER_CODE && mobileNo === MOCK_MOBILE_NO) {
        // Mock token
        const mockToken = "mock-dealer-token-12345";

        // Mock profile so the dashboard has a name + dealerCode (real API stores this)
        localStorage.setItem(
          "dealerInfo",
          JSON.stringify({ name: "Demo Dealer", dealerCode: "DEMO0000000001" }),
        );
        login(mockToken, "dealer");
        navigate("/dealerDash");
      } else {
        // Same behavior as 401 response
        setError("Invalid credentials. Please try again.");
        setDealerCode("");
        setMobileNo("");
      }
      // ==========================================
      // ORIGINAL API CODE — COMMENTED FOR MOCK DATA
      // ==========================================

      // const response = await api.post("/dealer/login", {
      //   dealerCode,
      //   mobileNo,
      // });
      // if (response.status === 200) {
      //   const dealerInfo = response.data?.dealer || null;
      //   if (dealerInfo) {
      //     localStorage.setItem("dealerInfo", JSON.stringify(dealerInfo));
      //   } else {
      //     localStorage.removeItem("dealerInfo");
      //   }
      //   login(response.data?.token || "dealer-auth-token", "dealer");
      //   navigate("/dealerDash", { state: { dealerCode } });
      // }
    // eslint-disable-next-line no-unused-vars -- mock login: needed again when the real API call is restored
    } catch (err) {
      // ==========================================
      // ORIGINAL API ERROR HANDLING
      // COMMENTED BECAUSE API IS NOT BEING USED
      // ==========================================

      // if (err.response?.status === 401) {
      //   setError("Invalid credentials. Please try again.");
      //   setDealerCode("");
      //   setMobileNo("");
      // } else {
      //   setError("Something went wrong while logging in.");
      // }
      setError("Something went wrong while logging in.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthShell
      icon={Store}
      roleLabel="Dealer"
      title="Dealer login"
      subtitle="Access your dashboard, quotations and customer records."
      bullets={[
        "Track your customers & vehicles",
        "Create and manage quotations",
        "View your dealership performance",
      ]}
    >
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Field label="Dealer code">
          <Input
            autoFocus
            value={dealerCode}
            onChange={(e) => setDealerCode(e.target.value)}
            placeholder="Enter your dealer code"
            required
          />
        </Field>
        <Field label="Mobile number">
          <PasswordInput
            value={mobileNo}
            onChange={(e) => setMobileNo(e.target.value)}
            placeholder="Registered mobile number"
            required
          />
        </Field>
        {error && (
          <p className="text-amber-300 text-xs bg-amber-400/10 border border-amber-400/20 rounded-lg px-3 py-2 leading-relaxed">
            {error}
          </p>
        )}
        <PrimaryButton
          type="submit"
          disabled={submitting}
          className="w-full justify-center"
        >
          {submitting ? (
            <>
              <Loader2 size={18} className="animate-spin" /> Signing in...
            </>
          ) : (
            "Login"
          )}
        </PrimaryButton>
        <Link
          to="/DealerForm"
          className="block text-center text-sm text-muted-foreground hover:text-accent transition-colors pt-1"
        >
          Not registered yet?{" "}
          <span className="underline decoration-line underline-offset-4">
            Register as a new dealer →
          </span>
        </Link>
        <Link
          to="/dealerActivate"
          className="block text-center text-sm text-muted-foreground hover:text-accent transition-colors"
        >
          Got an activation code?{" "}
          <span className="underline decoration-line underline-offset-4">
            Complete your registration →
          </span>
        </Link>
      </form>
    </AuthShell>
  );
};

export default DealerLogin;
