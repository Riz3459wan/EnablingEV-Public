import { useState } from "react";
import { useNavigate } from "react-router";
import { Users, Loader2 } from "lucide-react";
// eslint-disable-next-line no-unused-vars -- mock login: needed again when the real API call is restored
import api from "../../api/client";
import { useAuth } from "../../auth/AuthContext";
import AuthShell from "../../components/layout/AuthShell";
import Field, { Input, PasswordInput } from "../../components/ui/Field";
import { PrimaryButton } from "../../components/ui/Button";

const SubAdminLogin = () => {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      // ==============================
      // MOCK / HARDCODED LOGIN
      // ==============================

      const MOCK_USER_ID = "subAdmin";
      const MOCK_PASSWORD = "subadmin123";

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 800));

      if (userId === MOCK_USER_ID && password === MOCK_PASSWORD) {
        // Mock token
        const mockToken = "mock-subadmin-token-12345";

        login(mockToken, "subadmin");
        navigate("/subAdminDash");
      } else {
        // Same behavior as 401 response
        setError("Invalid credentials. Please try again.");
        setUserId("");
        setPassword("");
      }
      // ==========================================
      // ORIGINAL API CODE — COMMENTED FOR MOCK DATA
      // ==========================================

      // const response = await api.post("/CreateProfile/login", {
      //   userId,
      //   password,
      // });
      // if (response.status === 200) {
      //   localStorage.setItem(
      //     "CreateProfile",
      //     JSON.stringify(response.data.user),
      //   );
      //   login(response.data.token, "subadmin");
      //   navigate("/subAdminDash", { state: { userId } });
      // }
    // eslint-disable-next-line no-unused-vars -- mock login: needed again when the real API call is restored
    } catch (err) {
      // if (err.response?.status === 401) {
      //   setError("Invalid credentials. Please try again.");
      //   setUserId("");
      //   setPassword("");
      // } else {
      //   setError("Something went wrong while logging in.");
      // }
      setError("Somthing went wrong while logging in.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthShell
      icon={Users}
      roleLabel="Sub Admin"
      title="Sub admin login"
      subtitle="Manage your assigned dealers and customer records."
      bullets={[
        "View and manage assigned dealers",
        "Access customer records",
        "Coordinate with the admin team",
      ]}
    >
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Field label="User ID">
          <Input
            autoFocus
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            placeholder="Enter your user ID"
            required
          />
        </Field>
        <Field label="Password">
          <PasswordInput
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            required
          />
        </Field>
        {error && (
          <p className="text-amber-300 text-xs bg-amber-400/10 border border-amber-400/20 rounded-lg px-3 py-2 leading-relaxed">
            {error}
          </p>
        )}
        <PrimaryButton
          type="submit"
          disabled={submitting}
          className="w-full justify-center"
        >
          {submitting ? (
            <>
              <Loader2 size={18} className="animate-spin" /> Signing in...
            </>
          ) : (
            "Login"
          )}
        </PrimaryButton>
      </form>
    </AuthShell>
  );
};

export default SubAdminLogin;
