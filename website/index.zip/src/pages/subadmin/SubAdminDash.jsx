import { Link } from "react-router";
import {
  Truck,
  ListChecks,
  Users,
  ShieldCheck,
  FileText,
  Activity,
} from "lucide-react";

// Migrated from the old app's pages/subAdminDash/SubAdminDash.jsx. The old
// page mounted four full components inline inside one MUI grid (VehicleInfo,
// DisplayVehicleInfo, DealerInfo, SubAdminInfo) plus CreateQuotation. Same
// nav-hub pattern as AdminDash/DealerDash: each tool gets its own route.
const tools = [
  {
    to: "/VehicleInfo",
    icon: Truck,
    title: "Add Vehicle",
    description: "Register a newly manufactured vehicle's chassis and specs.",
    ready: true,
  },
  {
    to: "/displayVehicleInfo",
    icon: ListChecks,
    title: "Vehicle Info",
    description: "Browse dispatched vehicles across all dealers.",
    ready: true,
  },
  {
    to: "/vehicleStatus",
    icon: Activity,
    title: "Vehicle Status",
    description:
      "Track every vehicle's stage — in stock, assigned, or dispatched.",
    ready: true,
  },
  {
    to: "/dealerInfo",
    icon: Users,
    title: "Dealer Info",
    description: "Browse registered dealer records.",
    ready: true,
  },
  {
    to: "/subAdminInfo",
    icon: ShieldCheck,
    title: "Sub Admin Info",
    description: "Browse sub-admin accounts.",
    ready: true,
  },
  {
    to: "/createQuotation",
    icon: FileText,
    title: "Create Quotation",
    description: "Prepare a quotation on behalf of a dealer.",
    ready: true,
  },
];

const SubAdminDash = () => {
  return (
    <section className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-5xl mx-auto">
        <div className="mb-8">
          <span className="text-xs uppercase tracking-widest font-semibold text-accent mb-1 inline-block">
            Sub Admin
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Sub Admin Dashboard
          </h1>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {tools.map(({ to, icon: Icon, title, description }) => (
            <Link
              key={to}
              to={to}
              className="group p-6 rounded-3xl bg-card border border-line hover:border-accent/50 transition-all"
            >
              <div className="w-11 h-11 rounded-xl bg-accent/10 border border-accent/30 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                <Icon size={20} className="text-accent" />
              </div>
              <h2 className="font-semibold text-white mb-1">{title}</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {description}
              </p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SubAdminDash;
