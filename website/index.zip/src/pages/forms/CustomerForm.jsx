import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import api from "../../api/client";
import Modal from "../../components/ui/Modal";
import Field, { Input } from "../../components/ui/Field";
import { PrimaryButton } from "../../components/ui/Button";
import { useState } from "react";

const FIXED_PART_1 = "ME9EBCR";
const FIXED_PART_2 = "H268";
const mobilePattern = /^[6-9]\d{9}$/;
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const defaultValues = {
  chassisMid1: "",
  chassisMid2: "",
  name: "",
  mobileNumber: "",
  emailId: "",
  address: "",
  pincode: "",
  state: "",
  dist: "",
};

const customerSchema = z
  .object({
    chassisMid1: z.string(),
    chassisMid2: z.string(),
    name: z.string().min(1, "This field is required."),
    mobileNumber: z
      .string()
      .min(1, "This field is required.")
      .regex(mobilePattern, "Invalid mobile number."),
    emailId: z
      .string()
      .min(1, "This field is required.")
      .regex(emailPattern, "Invalid email address."),
    address: z.string().min(1, "This field is required."),
    pincode: z.string().min(1, "This field is required."),
    state: z.string().min(1, "This field is required."),
    dist: z.string().min(1, "This field is required."),
  })
  .superRefine((data, ctx) => {
    if (data.chassisMid1.length < 3 || data.chassisMid2.length < 3) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Chassis number segments must be 3 characters each.",
        path: ["chassisNumber"],
      });
    }
  });

const CustomerForm = () => {
  const [open, setOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const {
    control,
    handleSubmit,
    setValue,
    setError,
    clearErrors,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(customerSchema),
    defaultValues,
  });

  const handleClose = () => {
    reset(defaultValues);
    setOpen(false);
  };

  const chassisPartChange = (field) => (e) => {
    field.onChange(
      e.target.value.replace(/[^0-9A-Za-z]/g, "").slice(0, 3).toUpperCase(),
    );
    clearErrors("chassisNumber");
  };

  const handlePincodeChange = (field) => async (e) => {
    const value = e.target.value.replace(/[^0-9]/g, "").slice(0, 6);
    field.onChange(value);
    clearErrors("pincode");
    if (value.length === 6) {
      try {
        const res = await fetch(`https://api.postalpincode.in/pincode/${value}`);
        const [data] = await res.json();
        if (data.Status === "Success") {
          const { State, District } = data.PostOffice[0];
          setValue("state", State);
          setValue("dist", District);
        } else {
          setError("pincode", { message: "Invalid pin code." });
        }
      } catch {
        setError("pincode", { message: "Error fetching location details." });
      }
    }
  };

  const onSubmit = async (data) => {
    const chassisNumber =
      `${FIXED_PART_1}${data.chassisMid1}${FIXED_PART_2}${data.chassisMid2}`.toUpperCase();

    try {
      const validation = await api.post("/VehicleTable/chassis-validate", { chassisNumber });
      if (!validation.data.exists) {
        setError("chassisNumber", {
          message: "Invalid or already registered chassis number.",
        });
        return;
      }

      const dealerRes = await api.get(`/VehicleTable/dealerCode?chassisNumber=${chassisNumber}`);
      if (dealerRes.status !== 200) {
        alert("Dealer information not found for this chassis number.");
        return;
      }

      const { chassisMid1, chassisMid2, ...customerFields } = data;
      void chassisMid1;
      void chassisMid2;
      const payload = {
        ...customerFields,
        chassisNumber,
        dealerCode: dealerRes.data.dealerNameDealerCode,
      };

      const res = await api.post("/CustomerTable", payload);
      if (res.status === 201) {
        setSubmitted(true);
        handleClose();
      }
    } catch {
      alert("There was an error submitting the form.");
    }
  };

  return (
    <section className="pt-32 pb-24 px-4 text-center max-w-md mx-auto">
      <h1 className="text-3xl font-bold text-white mb-2">Customer Form</h1>
      <p className="text-muted-foreground mb-8">
        Register a customer against an existing vehicle chassis number.
      </p>
      {submitted && (
        <p className="text-accent text-sm mb-4">Customer registered successfully.</p>
      )}
      <PrimaryButton onClick={() => setOpen(true)}>Click here</PrimaryButton>

      <Modal open={open} onClose={handleClose} title="Customer Form">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <Field label="Chassis Number" error={errors.chassisNumber?.message}>
            <div className="flex items-center gap-2 justify-center text-sm text-muted-foreground">
              <span>{FIXED_PART_1}</span>
              <Controller
                name="chassisMid1"
                control={control}
                render={({ field }) => (
                  <input
                    maxLength={3}
                    value={field.value}
                    onChange={chassisPartChange(field)}
                    className="w-14 bg-transparent border-b border-line text-center text-white outline-none focus:border-accent"
                  />
                )}
              />
              <span>{FIXED_PART_2}</span>
              <Controller
                name="chassisMid2"
                control={control}
                render={({ field }) => (
                  <input
                    maxLength={3}
                    value={field.value}
                    onChange={chassisPartChange(field)}
                    className="w-14 bg-transparent border-b border-line text-center text-white outline-none focus:border-accent"
                  />
                )}
              />
            </div>
          </Field>

          <Field label="Name" error={errors.name?.message}>
            <Controller
              name="name"
              control={control}
              render={({ field }) => <Input {...field} error={!!errors.name} required />}
            />
          </Field>
          <Field label="Mobile Number" error={errors.mobileNumber?.message}>
            <Controller
              name="mobileNumber"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  onChange={(e) =>
                    field.onChange(e.target.value.replace(/[^0-9]/g, "").slice(0, 10))
                  }
                  error={!!errors.mobileNumber}
                  required
                />
              )}
            />
          </Field>
          <Field label="Email" error={errors.emailId?.message}>
            <Controller
              name="emailId"
              control={control}
              render={({ field }) => (
                <Input {...field} type="email" error={!!errors.emailId} required />
              )}
            />
          </Field>
          <Field label="Address" error={errors.address?.message}>
            <Controller
              name="address"
              control={control}
              render={({ field }) => <Input {...field} error={!!errors.address} required />}
            />
          </Field>
          <Field label="Pin Code" error={errors.pincode?.message}>
            <Controller
              name="pincode"
              control={control}
              render={({ field }) => (
                <Input
                  {...field}
                  onChange={handlePincodeChange(field)}
                  error={!!errors.pincode}
                  required
                />
              )}
            />
          </Field>
          <Field label="State" error={errors.state?.message}>
            <Controller
              name="state"
              control={control}
              render={({ field }) => <Input {...field} error={!!errors.state} required />}
            />
          </Field>
          <Field label="District" error={errors.dist?.message}>
            <Controller
              name="dist"
              control={control}
              render={({ field }) => <Input {...field} error={!!errors.dist} required />}
            />
          </Field>

          <PrimaryButton type="submit" disabled={isSubmitting} className="w-full justify-center">
            {isSubmitting ? "Submitting..." : "Submit"}
          </PrimaryButton>
        </form>
      </Modal>
    </section>
  );
};

export default CustomerForm;
