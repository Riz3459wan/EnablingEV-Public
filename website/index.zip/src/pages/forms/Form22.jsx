import { useCallback, useState } from "react";
import jsPDF from "jspdf";
import { Car, Truck, FileCheck2, Loader2 } from "lucide-react";
import letterheadImage from "../../assets/documents/Form_22.jpg";
import { fetchKnownChassis } from "../../utils/chassisLookup";
import { splitChassis } from "../../features/quotation/calc";
import Card from "../../components/ui/Card";
import Modal from "../../components/ui/Modal";
import { Input } from "../../components/ui/Field";
import { PrimaryButton } from "../../components/ui/Button";

// Migrated from the old app's Form_22.jsx + Form_22_Cargo.jsx (the old
// Form_22_Cargo.jsx was a pure subset, hardcoded to Cargo only, so it isn't
// carried over separately). Certificate wording and generated PDF are
// unchanged from the old app.
//
// Chassis entry was redesigned per the agreed "single source of truth"
// change: instead of typing any 6 characters (which let anyone generate a
// signed compliance certificate for a chassis that doesn't exist), the
// dealer/admin now searches real, already-registered chassis numbers
// (see utils/chassisLookup.js).

const Form22 = () => {
  const [typeSelectorOpen, setTypeSelectorOpen] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [formType, setFormType] = useState(null); // 'rikshaw' | 'cargo'
  const [chassisOptions, setChassisOptions] = useState([]);
  const [selectedChassis, setSelectedChassis] = useState("");
  const [chassisInput, setChassisInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const brandName = formType === "rikshaw" ? "JHATPAT JIO" : "HALCHAL";
  const vehiclePrefix = formType === "rikshaw" ? "ME" : "MC";
  const isValidSelection =
    !!selectedChassis && chassisOptions.includes(selectedChassis);

  const loadChassis = useCallback(async (type) => {
    setLoading(true);
    setError("");
    try {
      const list = await fetchKnownChassis({ vehicleType: type });
      setChassisOptions(list);
      if (list.length === 0) {
        setError(
          "No registered chassis numbers found for this vehicle type yet.",
        );
      }
    } catch {
      setError("Unable to load chassis numbers. Please try again.");
    } finally {
      setLoading(false);
    }
  }, []);

  const handleTypeSelect = (type) => {
    setFormType(type);
    setSelectedChassis("");
    setChassisInput("");
    setTypeSelectorOpen(false);
    setFormOpen(true);
    loadChassis(type);
  };

  const handleChassisInput = (e) => {
    const value = e.target.value.toUpperCase();
    setChassisInput(value);
    setSelectedChassis(chassisOptions.includes(value) ? value : "");
  };

  const handleDownload = () => {
    if (!isValidSelection) return;

    const { mid1, mid2 } = splitChassis(selectedChassis);
    const paragraphContent = `
Certified  that ${brandName} ( Brand  name  of vehicle )  bearing  chassis no.
${selectedChassis}  and  engine number or  motor  number  in  case of  battery
operated vehicles ${vehiclePrefix}${mid1}${mid2} complies with the provision of motor vehicle acts 1998
and rules made there under.






ENABLING E-VEHICLE PRIVATE LTD



Authorized Signatory

Form-22  shall be issued  with the signature  of the manufacturer  /ENABLING  
E-VEHICLE PRIVATE LTD duly printed in the form itself by affixing facsimile signature in ink under the hand and seal of manufacturer/ ENABLING E-VEHICLE PRIVATE LTD.
`;

    const pdf = new jsPDF("p", "mm", "a4");
    const img = new Image();
    img.src = letterheadImage;
    img.onload = () => {
      const pdfWidth = pdf.internal.pageSize.getWidth();
      pdf.addImage(
        img,
        "JPEG",
        0,
        0,
        pdfWidth,
        pdf.internal.pageSize.getHeight(),
      );

      pdf.setFontSize(13.5);
      pdf.text("FORM 22", pdfWidth / 2, 70, { align: "center" });
      pdf.text(
        "[See rules 47(g), 115(2), 115(6), 115(1), 124, 126(A) and 127]",
        pdfWidth / 2,
        80,
        { align: "center" },
      );
      pdf.text(
        "INITIAL CERTIFICATE OF COMPLIANCE WIITH POLLUTION, STANDARDS,",
        pdfWidth / 2,
        90,
        { align: "center" },
      );
      pdf.text(
        "SAFETY STANDARDS OF COMPONENT AND ROAD WORTHINESS",
        pdfWidth / 2,
        100,
        { align: "center" },
      );

      const lines = pdf.splitTextToSize(paragraphContent, pdfWidth - 20);
      pdf.text(lines, 13, 130);

      pdf.save(
        formType === "rikshaw" ? "form_22_rikshaw.pdf" : "form_22_cargo.pdf",
      );

      setSelectedChassis("");
      setChassisInput("");
      setFormOpen(false);
    };
  };

  return (
    <section className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center">
      <div className="w-full max-w-lg text-center">
        <span className="text-xs uppercase tracking-widest font-semibold text-accent mb-1 inline-block">
          RTO Compliance
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-3">
          Form 22
        </h1>
        <p className="text-muted-foreground text-sm sm:text-base mb-8 max-w-md mx-auto">
          Initial certificate of compliance with pollution, safety and
          road-worthiness standards. Search a registered chassis number to
          generate the signed certificate as a PDF.
        </p>

        <Card className="p-8 sm:p-10">
          <div className="mx-auto mb-5 w-14 h-14 rounded-full bg-accent/10 border border-accent/30 flex items-center justify-center">
            <FileCheck2 className="text-accent" size={26} />
          </div>
          <PrimaryButton
            onClick={() => setTypeSelectorOpen(true)}
            className="mx-auto"
          >
            Generate Form 22
          </PrimaryButton>
        </Card>
      </div>

      {/* Step 1: choose Rikshaw or Cargo */}
      <Modal
        open={typeSelectorOpen}
        onClose={() => setTypeSelectorOpen(false)}
        title="Select Form Type"
      >
        <div className="grid sm:grid-cols-2 gap-4">
          <button
            onClick={() => handleTypeSelect("rikshaw")}
            className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-accent/50 hover:bg-white/[0.05] transition-all text-center"
          >
            <Car className="mx-auto mb-2 text-accent" size={32} />
            <p className="font-semibold text-white text-sm">Rikshaw</p>
            <p className="text-xs text-muted-foreground mt-1">
              Form 22
              <br />
              Brand: JHATPAT JIO
            </p>
          </button>
          <button
            onClick={() => handleTypeSelect("cargo")}
            className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-accent/50 hover:bg-white/[0.05] transition-all text-center"
          >
            <Truck className="mx-auto mb-2 text-accent" size={32} />
            <p className="font-semibold text-white text-sm">Cargo / Loader</p>
            <p className="text-xs text-muted-foreground mt-1">
              Form 22
              <br />
              Brand: HALCHAL
            </p>
          </button>
        </div>
      </Modal>

      {/* Step 2: search a registered chassis number */}
      <Modal
        open={formOpen}
        onClose={() => setFormOpen(false)}
        title={`Form 22 - ${formType === "rikshaw" ? "Rikshaw" : "Cargo"}`}
      >
        {loading ? (
          <div className="flex justify-center py-6">
            <Loader2 size={20} className="animate-spin text-accent" />
          </div>
        ) : (
          <div className="space-y-5 text-left">
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-200">
                Chassis Number
              </label>
              <Input
                value={chassisInput}
                onChange={handleChassisInput}
                list="form22-chassis-options"
                placeholder="Start typing to search..."
                autoComplete="off"
              />
              <datalist id="form22-chassis-options">
                {chassisOptions.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
              {chassisInput && !isValidSelection && (
                <p className="text-amber-300 text-xs mt-2">
                  Not a registered chassis number for this vehicle type.
                </p>
              )}
            </div>
            {error && <p className="text-red-400 text-xs">{error}</p>}
            <PrimaryButton
              onClick={handleDownload}
              disabled={!isValidSelection}
              className="w-full justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Download Certificate
            </PrimaryButton>
          </div>
        )}
      </Modal>
    </section>
  );
};

export default Form22;
