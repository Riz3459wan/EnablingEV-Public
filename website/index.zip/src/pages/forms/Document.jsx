import { useLocation, useNavigate } from "react-router";
import jsPDF from "jspdf";
import certificateImage from "../../assets/documents/certificate.jpg";
import letterOfIntentImage from "../../assets/documents/letter-of-intent.jpg";
import requestLetterImage from "../../assets/documents/request-letter.jpg";
import Card from "../../components/ui/Card";
import { PrimaryButton, SecondaryButton } from "../../components/ui/Button";

const formatDate = () => {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, "0")}-${String(d.getMonth() + 1).padStart(2, "0")}-${d.getFullYear()}`;
};

const Document = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { submittedData } = location.state || {};

  if (!submittedData) {
    return (
      <section className="pt-32 pb-24 px-4 text-center max-w-md mx-auto">
        <h2 className="text-2xl font-bold text-white mb-4">
          No data available. Please submit the form first.
        </h2>
        <PrimaryButton onClick={() => navigate("/")}>Go to Home</PrimaryButton>
      </section>
    );
  }

  const { dealerCode, mobileNo } = submittedData;
  const formattedDate = formatDate();

  const loiContent = `This is to certify that M/s ${submittedData.name}, located at ${submittedData.address}, ${submittedData.dist}, ${submittedData.state} - ${submittedData.pinCode}, and GSTIN ${submittedData.gstin}, has been duly authorized for the sale and service of our battery-operated e-Rickshaw model "JHATPAT-JIO." The aforementioned model is manufactured by M/s Enabling E-Vehicle Private Ltd., which has its registered office at 10A/21, Vasundhara, Ghaziabad, Uttar Pradesh 201012, bearing GSTIN 09AAHCE4716B1ZW.



This authorization is granted in accordance with the terms and conditions outlined in our dealer agreement for the JHATPAT-JIO model, as well as for any forthcoming models that may be introduced. We will provide necessary updates regarding any new models in due course.






For Enabling E-Vehicle Private Ltd.,





Authorized Signatory`;

  const reqContent = `REF: ${submittedData.RQreferenceId}

To,
The Regional Transport Officer (RTO)
${submittedData.rtoOffice}, ${submittedData.state}

Subject: Authorization for "JHATPAT Jio"


Dear Sir/Madam,

We wish to inform you that M/s ${submittedData.name}, located at ${submittedData.address}, ${submittedData.dist}, ${submittedData.state} - ${submittedData.pinCode}, has been appointed as an authorized dealer for the sales and service of our eRickshaw model "JHATPAT Jio" within the ${submittedData.dist} region.



In light of this, we kindly request your office to process the registration of the eRickshaw vehicles manufactured by ENABLING E-VEHICLE PRIVATE LIMITED, as presented by our authorized dealer.

We appreciate your cooperation in this matter.




Thank you.

Yours sincerely,





ENABLING E-VEHICLE PRIVATE LIMITED`;

  const certContent = `This is to certify that M/S ${submittedData.name}, Address: ${submittedData.address}, GST Number: ${submittedData.gstin}, is an authorized dealer for JhatPat Jio e-rickshaws. The dealer is entitled to sell, promote, and provide after-sales service for JhatPat Jio products in the ${submittedData.dist} region.`;

  const handleGetCertificate = () => {
    const pdf = new jsPDF();

    pdf.addImage(letterOfIntentImage, "JPEG", 0, 0, 210, 297);
    pdf.setFontSize(20);
    pdf.text("LETTER OF INTENT (LOI)", 105, 75, { align: "center" });
    pdf.setFontSize(16);
    pdf.text("TO WHOMSOEVER IT MAY CONCERN", 105, 85, { align: "center" });
    pdf.setFontSize(13);
    pdf.text(`Date: ${formattedDate}`, 163, 50);
    pdf.text(loiContent, 10, 100, { maxWidth: 190 });
    pdf.addPage();

    pdf.addImage(certificateImage, "JPEG", 0, 0, 210, 160);
    pdf.text(formattedDate, 20, 130);
    pdf.text(certContent, 10, 70, { maxWidth: 190 });
    pdf.addPage();

    pdf.addImage(requestLetterImage, "JPEG", 0, 0, 210, 297);
    pdf.text(`Date: ${formattedDate}`, 163, 50);
    pdf.text(reqContent, 10, 70, { maxWidth: 190 });

    pdf.save("certificates.pdf");
    navigate("/");
  };

  return (
    <section className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-lg mx-auto text-center">
      <Card className="p-8 sm:p-10">
        <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Welcome</h1>
        <p className="text-muted-foreground mb-6">
          Thank you for joining us! Together with a trusted brand, we'll create new success stories.
        </p>

        <div className="bg-surface border border-line rounded-2xl p-4 text-left mb-8 space-y-1">
          <p className="text-sm text-muted-foreground">
            User ID: <span className="text-white font-semibold">{dealerCode}</span>
          </p>
          <p className="text-sm text-muted-foreground">
            Password: <span className="text-white font-semibold">{mobileNo}</span>
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <PrimaryButton onClick={handleGetCertificate}>Get certificate</PrimaryButton>
          <SecondaryButton onClick={() => navigate("/dealerLogin")}>Go to login</SecondaryButton>
        </div>
      </Card>
    </section>
  );
};

export default Document;
